from glob import glob

a = glob("*.py")

for i in a:
    print(type(i))
    print(i)

exec(open("bus.py").read())
