#!C:\Users\chosun\AppData\Local\Programs\Python\Python37-32\python.exe
print("content-type: text/html; charset=utf-8\n")

a = 3+4+5
b = a + 3

print('''
<h1> <a href="http://117.16.24.58/">Hello</a></h1>
<h2> <a href="index.html">folder2</a> </h2>
''')
print(b)

print('???????????')
