#
# a='hello world'
# print('world' in a)

# import os.path
# print(os.path.exists('버스.mp4'))

# a=input('password?')
# if a == 'rsk':
#     print('yeah!')
# else:
#     print('nope')

user_id=input('id?')
user_pwd=input('password?')

# if user_id== 'calop':
#     if user_pwd=='123':
#         print("succesfully log-in")
#     else:
#         print("nope")

if user_id == 'calop' and user_pwd == '123':
    print('asdfa')
elif user_id == 'calop123' and user_pwd == '1233':
    print('asdfa')
else:
    print('nnnnnnnnnooo')
